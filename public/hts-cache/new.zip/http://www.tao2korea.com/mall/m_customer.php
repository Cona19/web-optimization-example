<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Ÿ�����ڸ���</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<META HTTP-EQUIV="imagetoolbar" CONTENT="no">
  <link rel="StyleSheet" HREF="css/button_basic.css" type="text/css">
  <link rel="StyleSheet" HREF="skin/basic/css/morning.css" type="text/css">  
  <link rel="StyleSheet" HREF="skin/basic/css/orbit.css" type="text/css">

  <script language="javascript" src="js/jquery-1.7.2.min.js"></script>
  <script language="javascript" src="js/jquery.orbit.js"></script>

  <script type="text/javascript" src="./cheditor/cheditor.js"></script>
  <script type="text/javascript" src="js/hd_libc.js"></script>
  <script type="text/javascript" src="js/hd_min.js"></script>
  <script type="text/javascript" src="js/hd_objc.js"></script>
  <script type="text/javascript" src="js/skin_basic.js"></script>
  <script type="text/javascript" src="js/back_bg.js"></script>
  











































	<!---- �����߾� ----->
	<SCRIPT language="JavaScript" type="text/javascript">
	//<!-- Overture Korea
	//var ysm_accountid  = "�����߾�߱��ڵ��Է�"; //1FC5C0J93LS3OLH662MVGVT638S
	//document.write("<SCR" + "IPT language='JavaScript' type='text/javascript' " 
	//+ "SRC=//" + "srv3.wa.marketingsolutions.yahoo.com" + "/script/ScriptServlet" + "?aid=" + ysm_accountid 
	//+ "></SCR" + "IPT>");
	// -->
	</SCRIPT>
	<!---- �����߾� ----->


		<script type="text/javascript" src="http://wcs.naver.net/wcslog.js"></script>
	<script type="text/javascript">
	if(!wcs_add) var wcs_add = {};
	wcs_add["wa"] = "AccountId";
	wcs.inflow("www.tao2korea.com");
	</script>
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" >


<table width="980" border="0" cellspacing="0" cellpadding="0" align="center" style="margin:0 auto">
<tr valign="top">
<td>
	  	  <!-- ���ú� ��ǰ -->
		<div style="position:relative;left:0px;top:0px;">
		  <div style="position:absolute; z-index:1; left:980px; top:167px;">
				<!------------------------------------ ���ú� ��ǰ ����  ------------------------------------------>
<div style="position:absolute">
  <div id="flying" style="position:relative;left:10px;top:0px">

	

<!--
	  <div style="width:59px">
		<a href='m_giftcard.php'><img src="skin/basic/image/bt_giftcard.gif"></a>
	  </div>
-->




	  <table width="59" border="0" cellspacing="0" cellpadding="0" background="skin/basic/image/R_ly_box_02.gif">
		<form name="LeftGoodsListForm">
		<input type="hidden" name="f_up_no" value="0">
		<input type="hidden" name="f_down_no" value="3">
		<tr>
		  <td><img src="skin/basic/image/R_ly_box_01.gif"></td>
		</tr>
		<tr>
		  <td align=center class=thm7 style="padding-bottom:5px">
		  		  <font color="#4D4D4D"><b>100</b> EA</font>
		  		  </td>
		</tr>
		<tr>
		  <td align=center><img src="skin/basic/image/N_ly_todayview_up.gif" class="banner_right"></td>
		</tr>
		<tr>
		  <td align=center style='padding-top:10px;padding-bottom:10px'>
								<div id="banner_warp" >
					<div id="banner_container">
						<div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=560'><img src="./shop_image/201511/20151126_163336.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=568'><img src="./shop_image/201601/00%2811%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=580'><img src="./shop_image/201601/00.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=585'><img src="./shop_image/201601/3D%C4%C9%C0%CC%BD%BA.png5.png" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=586'><img src="./shop_image/201601/00%287%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=497'><img src="./shop_image/201510/00.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=486'><img src="./shop_image/201509/00%285%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=270'><img src="./shop_image/201510/000.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=470'><img src="./shop_image/201508/01.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=634'><img src="./shop_image/201603/00%2833%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=678'><img src="" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=650'><img src="./shop_image/201603/%C0%CC%B9%CC%C1%F6_5.png" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=691'><img src="./shop_image/201605/%B0%ED%BE%E7%C0%CC%B0%C5%C4%A12.png" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=693'><img src="./shop_image/201605/%B3%AB%C7%CF%BB%EA%C7%D8%B8%D42.png" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=195'><img src="./shop_image/201503/8.JPG" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=196'><img src="./shop_image/201503/20150327_004953.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=267'><img src="./shop_image/201504/%B3%AF%B0%B3%BE%F8%B4%C2%BC%B1%C7%B3%B1%E2.png" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=435'><img src="./shop_image/201507/360%EF%B8%3F20150701203256511%283%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=187'><img src="./shop_image/201503/360%EF%B8%3F20150314003008266.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=69'><img src="./shop_image/201503/360%EF%B8%3F20150318001003019.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=182'><img src="./shop_image/201504/%C1%A6%B8%F1_%BE%F8%C0%BD_3.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=602'><img src="" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=480'><img src="./shop_image/201508/360%EF%B8%3F20150806201047688.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=95'><img src="./shop_image/201503/360%EF%B8%3F20150109132750885.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=642'><img src="./shop_image/201603/00%2850%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=528'><img src="./shop_image/201510/001.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=442'><img src="./shop_image/201507/360%EF%B8%3F20150706002208417.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=475'><img src="./shop_image/201508/00%2810%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=572'><img src="./shop_image/201512/00%285%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=633'><img src="./shop_image/201603/00%2830%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=386'><img src="./shop_image/201508/00%2814%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=403'><img src="./shop_image/201506/360%EF%B8%3F20150602015918228.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=430'><img src="./shop_image/201506/360%EF%B8%3F20150627154607122.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=454'><img src="./shop_image/201507/360%EF%B8%3F20150728215546985.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=455'><img src="./shop_image/201507/360%EF%B8%3F20150728222933704.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=481'><img src="./shop_image/201508/360%EF%B8%3F20150826004141573.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=503'><img src="./shop_image/201510/00%287%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=529'><img src="./shop_image/201510/00%2818%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=531'><img src="./shop_image/201511/00.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=571'><img src="./shop_image/201512/00%283%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=574'><img src="./shop_image/201512/00%289%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=581'><img src="./shop_image/201601/00%282%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=589'><img src="./shop_image/201601/00%2817%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=635'><img src="./shop_image/201603/00%2836%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=640'><img src="./shop_image/201603/00%2845%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=648'><img src="./shop_image/201603/00%2859%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=660'><img src="./shop_image/201604/00%2810%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=706'><img src="./shop_image/201606/00%283%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=51'><img src="./shop_image/201503/360%EF%B8%3F20150108013130212.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=52'><img src="./shop_image/201503/360%EF%B8%3F20150108012114329.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=53'><img src="./shop_image/201503/360%EF%B8%3F20141227204514803.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=204'><img src="./shop_image/201503/360%EF%B8%3F20150328212607562.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=208'><img src="./shop_image/201503/360%EF%B8%3F20150329150130177.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=210'><img src="./shop_image/201503/360%EF%B8%3F20150108012114329%283%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=250'><img src="./shop_image/201504/360%EF%B8%3F20150409170507253.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=322'><img src="./shop_image/201505/360%EF%B8%3F20150108012114329.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=326'><img src="./shop_image/201505/360%EF%B8%3F20150510221926671.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=567'><img src="" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=643'><img src="./shop_image/201603/00%2852%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=715'><img src="./shop_image/201606/00%2830%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=727'><img src="./shop_image/201606/01%288%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=754'><img src="./shop_image/201607/01%2827%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=669'><img src="./shop_image/201604/00%2830%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=670'><img src="./shop_image/201604/00%2833%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=685'><img src="./shop_image/201605/00%2812%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=689'><img src="./shop_image/201605/00%2821%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=704'><img src="./shop_image/201605/00%2846%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=709'><img src="./shop_image/201606/00%2812%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=710'><img src="./shop_image/201606/00%2815%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=712'><img src="./shop_image/201606/00%2821%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=720'><img src="./shop_image/201606/00%2848%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=721'><img src="./shop_image/201606/00%2851%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=723'><img src="./shop_image/201606/01.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=725'><img src="./shop_image/201606/01%283%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=726'><img src="./shop_image/201606/01%285%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=732'><img src="./shop_image/201606/01%2814%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=733'><img src="./shop_image/201606/01%2817%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=750'><img src="./shop_image/201607/01%2818%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=755'><img src="./shop_image/201607/01%2830%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=699'><img src="./shop_image/201605/00%2834%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=700'><img src="./shop_image/201605/00%2837%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=701'><img src="./shop_image/201605/00%2840%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=702'><img src="./shop_image/201605/00%2843%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=705'><img src="./shop_image/201606/00.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=707'><img src="./shop_image/201606/00%286%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=708'><img src="./shop_image/201606/00%289%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=718'><img src="./shop_image/201606/00%2839%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=719'><img src="./shop_image/201606/00%2845%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=722'><img src="./shop_image/201606/00%2854%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=747'><img src="" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=734'><img src="./shop_image/201606/01%2820%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=738'><img src="./shop_image/201607/01.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=743'><img src="./shop_image/201607/01%289%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=744'><img src="./shop_image/201607/01%2812%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=745'><img src="./shop_image/201607/01%2815%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=751'><img src="./shop_image/201607/01%2821%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div><div class='banner'>							<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=752'><img src="./shop_image/201607/01%2824%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=641'><img src="./shop_image/201603/00%2847%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=737'><img src="./shop_image/201607/00.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

													<div style='margin-bottom:5px;padding-bottom:5px;'><a href='m_mall_detail.php?ps_goid=717'><img src="./shop_image/201606/00%2836%29.jpg" width="50" height="50" style='border:1px solid #dddddd'></a></div>

						</div>					</div>
				</div>
						  </td>
		</tr>
		<tr>
		  <td align=center><img src="skin/basic/image/N_ly_todayview_down.gif" class="banner_left"></td>
		</tr>
		<tr>
		  <td><a href="#" onfocus='this.blur()'><img src="skin/basic/image/R_ly_box_03.gif"></a></td>
		</tr>
		</form>
	  </table>

		<style type="text/css">
		#banner_warp{overflow:hidden;position:relative;text-align:left}
		#banner_container{position:absolute;}
		.banner{width:55px;height:240px;border:0px solid #dddddd;float:left;text-align:center}
		.banner_left{cursor:pointer}
		.banner_right{cursor:pointer}
		</style>


		<script type="text/javascript">
		$(function(){

			var show_num = 1;
			var auto_num = 1;
			var move_obj;

			var obj_width = $('.banner').width(); //��ü ����ũ��
			var obj_height = $('.banner').height(); //��ü ����ũ��
			var obj_num = $('.banner').length; //��ü����
			var banner_container = $('#banner_container');

			$("#banner_warp").css({"width":obj_width*show_num,"height":obj_height}); //��üƲ
			banner_container.css("width",obj_width*obj_num);

			function next_banner(n){
				move_obj = obj_width*(n-1);
				banner_container.animate({left:move_obj},500);
				$("#v").val(n);//Ȯ�ΰ�
			}

			$(".banner_left").on("click",function(){
				var bnum = ((obj_num-show_num-2)*-1);
				if(bnum <= auto_num){
					auto_num = auto_num-1;
				}
				next_banner(auto_num);
			}); 

			$(".banner_right").on("click",function() { 
				if(auto_num < 1){
					auto_num = auto_num+1;
				}
				next_banner(auto_num);
			}); 


		})
		</script>


	<!--------- ���ú���ǰ �� ----------->
  </div>
 </div>


<script type="text/javascript">
HD.flying.add({
	id:"flying",
	space:10
});
</script>
<!------------------------------------ ���ú� ��ǰ �� --------------------------------------------->			</div>
		</div>
	  <!--// ���ú� ��ǰ -->
	        
	<table width="980" border="0" cellspacing="0" cellpadding="0">
	<tr height="35">
    <td><a href="javascript:bookmark()"><img src="skin/basic/images/main_top_util.gif" border="0"></a></td>
	<td width="100%" align="right">
		        	<div style="padding:0 0 0 0">
			<table cellpadding="0" cellspacing="0">
			<tr>
			<td><a href="index.php">Ȩ</a>&nbsp;|&nbsp;</td>
			<td><a href="m_login.php">�α���</a>&nbsp;<font style='color:#c7c6c4'>|</font>&nbsp;</td>
			<td><a href="m_member.php">ȸ������</a>&nbsp;<font style='color:#c7c6c4'>|</font>&nbsp;</td>
			<td><a href="m_cart.php">��ٱ���</a>&nbsp;<font style='color:#c7c6c4'>|</font>&nbsp;</td>
			<td><a href="m_mypage.php">����������</a>&nbsp;<font style='color:#c7c6c4'>|</font>&nbsp;</td>
			<td><a href="m_order.php">�ֹ������ȸ</a></td>
			</tr>
			</table>
            </div>			
				
	</td>    
	</tr>
	</table>
	
	<table width="980" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td height="131"><a href='http://www.tao2korea.com' target='_self'><img src='http://cfile9.uf.tistory.com/image/2705933C5526E3D7057B4C' width='318' height='80' border='0'></a></td>
	<td width="100%" align="right">
		<table border="0" cellspacing="0" cellpadding="0">
				<form method="get" action="m_search.php" name="morning_top_search" onSubmit="javascript:return check_top_search()">
				<input type="hidden" name="ps_mode" value="search">
				<input type="hidden" name="url" value="m_customer.php">

		<tr>
		<td><input type="text" name="ps_search" maxlength="50" style="width:180px;border:1px solid #dcdcdc;height:24px;font-size:14px;color:#000000;padding:0 0 0 0;font-weight:bold" autocomplete="off" id="auto_complete1"></td>
		<td><input type=image src="skin/basic/images/main_search_btn.gif" style="border:0"></td>
		</tr>
		</form>
		</table>
		<script type="text/javascript">
		HD.autocomplete().init({
			id:"auto_complete1",
			maxnum:5,
			boxstyle:"background-color:#ffffff;border:1px solid gray;padding:5px",
			itemstyle:"color:#5D5D5D;letter-spacing:0px;padding:2px",
			hiltestyle:"background-color:#E7E7E7",
			nonestyle:""
		});
		</script>	
			</td>
	</tr>
	</table>
	<table width="980" border="0" cellspacing="0" cellpadding="0">
	<tr>
    <td><a href="m_mall_best2.php"><img src="skin/basic/images/main_nav_01.gif" ></a></td>
    <td><a href="m_mall_best3.php"><img src="skin/basic/images/main_nav_02.gif" ></a></td>
    <td><a href="m_mall_best4.php"><img src="skin/basic/images/main_nav_03.gif" ></a></td>
    <td><a href="m_page.php?ps_pname=comm"><img src="skin/basic/images/main_nav_04.gif" ></a></td>
    <td><a href="m_page.php?ps_pname=page_use"><img src="skin/basic/images/main_nav_05.gif" ></a></td>
    </tr>
    </table>

    <table width="980" border="0" cellspacing="0" cellpadding="0">
    <tr valign="top">
    <td width="200" bgcolor="ffffff" style="padding:20px 0 0 0">

        <table width="173" border="0" cellspacing="0" cellpadding="0">
                                    <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category1')" onmouseout="javascript:hide('category1')">

                        
                            <div style='position:relative;left:0px;top:0px;z-index:10' >
                            <div id='category1' style='position:absolute; width:175px; z-index:10; left: 140px; top: -6px;display:none'>
                            <table width='100%' border='0' bordercolor='#dddddd' cellspacing='0' cellpadding='6' align='center' style='border-collapse:collapse;border:1px solid #dddddd'>
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=01010000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�ȵ���̵�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=01020000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>������</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=01030000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>������</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=01040000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�̴�PC / TV�ڽ�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                            </table>
                            </div>
                            </div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=01000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=01000000" class="link01">�ȵ���̵�/�������е�</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category2')" onmouseout="javascript:hide('category2')">

                        <div style='position:relative;left:0px;top:0px'><div id='category2' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=02000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=02000000" class="link01">����Ʈ��</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category3')" onmouseout="javascript:hide('category3')">

                        <div style='position:relative;left:0px;top:0px'><div id='category3' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=03000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=03000000" class="link01">����Ʈ��ġ</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category4')" onmouseout="javascript:hide('category4')">

                        <div style='position:relative;left:0px;top:0px'><div id='category4' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=13000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=13000000" class="link01">����������</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category5')" onmouseout="javascript:hide('category5')">

                        
                            <div style='position:relative;left:0px;top:0px;z-index:10' >
                            <div id='category5' style='position:absolute; width:175px; z-index:10; left: 140px; top: -6px;display:none'>
                            <table width='100%' border='0' bordercolor='#dddddd' cellspacing='0' cellpadding='6' align='center' style='border-collapse:collapse;border:1px solid #dddddd'>
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=04020000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>����+ī�޶�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=04030000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�̾���/�����/���̺�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                            </table>
                            </div>
                            </div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=04000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=04000000" class="link01">����+�����+ī�޶�</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category6')" onmouseout="javascript:hide('category6')">

                        
                            <div style='position:relative;left:0px;top:0px;z-index:10' >
                            <div id='category6' style='position:absolute; width:175px; z-index:10; left: 140px; top: -6px;display:none'>
                            <table width='100%' border='0' bordercolor='#dddddd' cellspacing='0' cellpadding='6' align='center' style='border-collapse:collapse;border:1px solid #dddddd'>
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=05010000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>Ű����</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=05020000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>���콺</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=05030000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>Ű����+���̽� ������</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=05040000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�����е�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                            </table>
                            </div>
                            </div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=05000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=05000000" class="link01">Ű����+���콺+�����е�</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category7')" onmouseout="javascript:hide('category7')">

                        
                            <div style='position:relative;left:0px;top:0px;z-index:10' >
                            <div id='category7' style='position:absolute; width:175px; z-index:10; left: 140px; top: -6px;display:none'>
                            <table width='100%' border='0' bordercolor='#dddddd' cellspacing='0' cellpadding='6' align='center' style='border-collapse:collapse;border:1px solid #dddddd'>
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=06010000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�º�����ȣ�ʸ�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=06020000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>�º������̽�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=06030000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>����Ʈ�� ��ȣ�ʸ�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=06040000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>����Ʈ�� ���̽�</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)-->
                                  <tr>
                                    <td bgcolor=#ffffff onclick=location.href='m_mall_list.php?ps_ctid=06060000' onMouseOver=this.style.backgroundColor="#FFF5C0" onMouseOut=this.style.backgroundColor="" style='cursor:pointer;border:1px solid #dddddd'>
                                      <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                        <tr>
                                          <td width=10><img src='skin/basic/image/R_icon_02.gif' width='3' height='3'></td>
                                          <td>Ű����+���̽� ������(��ŷŰ��������)</td>
                                        </tr>
                                      </table>
                                    </td>
                                  </tr>
                              <!-- ���극�̾� (����ī�װ��� ����ŭ �ݺ����� �迭�� ���)end-->
                            
                            </table>
                            </div>
                            </div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=06000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=06000000" class="link01">�������̽� �� ��ȣ�ʸ�</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category8')" onmouseout="javascript:hide('category8')">

                        <div style='position:relative;left:0px;top:0px'><div id='category8' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=07000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=07000000" class="link01">�Ǽ��縮�ֺ����</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category9')" onmouseout="javascript:hide('category9')">

                        <div style='position:relative;left:0px;top:0px'><div id='category9' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=08000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=08000000" class="link01">�Ƿ�&�м�</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category10')" onmouseout="javascript:hide('category10')">

                        <div style='position:relative;left:0px;top:0px'><div id='category10' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=09000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=09000000" class="link01">E-book & �����º���</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category11')" onmouseout="javascript:hide('category11')">

                        <div style='position:relative;left:0px;top:0px'><div id='category11' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=10000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=10000000" class="link01">��Ÿ��ȭ / ��Ȱ��ǰ</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category12')" onmouseout="javascript:hide('category12')">

                        <div style='position:relative;left:0px;top:0px'><div id='category12' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=11000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=11000000" class="link01">����/��������ǰ</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                                        <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�)-->
                      <tr> 
                        <td height="28" style="" onmouseover="javascript:show('category13')" onmouseout="javascript:hide('category13')">

                        <div style='position:relative;left:0px;top:0px'><div id='category13' style='position:absolute; width:175px; z-index:1; left: 150px; top: -7px;display:none'></div></div><!-- ���극�̾� �ҷ�����-->
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr> 
                              <td onclick=location.href='m_mall_list.php?ps_ctid=12000000' style="cursor:pointer"><a href="m_mall_list.php?ps_ctid=12000000" class="link01">�ֿϵ�����ǰ</a><!-- ī�װ����̸� --></td>
                            </tr>
                          </table>

                        </td>
                      </tr>
                      <!-- ī�װ��� ���θ޴� ���� (����ī�װ��� ����ŭ �ݺ�) end -->
                            </table>
<div style="padding:40px 0 0 0">
<img src='./board_data/cc4.jpg' width='173' height='133' border='0'></div>
      </td>
        <td>
<div style="height:20px"></div>




<!-- ������ġǥ�� -->

			<div style='background-color:#F5F5F5;border:1px solid #dddddd;padding:5px 5px 5px 10px;text-align:left'>
				<img src='./admin/img/icon_folder01.gif'>&nbsp;&nbsp;&nbsp;������ġ : <a href="index.php" class=category_m>HOME</a> > ��������
			</div>
			<div style="height:15px"></div>

<table width="95%" border="0" cellspacing="0" cellpadding="0" align=center>
  <tr valign="top"> 
    <td style='text-align:left'>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="skin/basic/image/N_custormer_call_bg.gif" height="171" valign="top" style="padding-left:24px;">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" style='margin-top:40px'>
              <tr>
                <td style="padding-bottom:9px;color:#ffffff;text-align:left" class=n>TEL 
                  : <b>070-7660-6773</b><br>
                  FAX : <b></b><br>
                  E-MAIL : <b><a href="javascript:open_window('mailer', 'm_mailer.php?ps_rmail=ZHIxcGhvbmVAbmF2ZXIuY29t&ps_rname=Ÿ�����ڸ���', 40, 40, 420, 380, 0, 0, 0, 0, 0);"><font color=#ffffff>dr1phone@naver.com</font></a></b></td>
              </tr>
              <tr>
                <td background="skin/basic/image/M_line_02.gif" height="1"></td>
              </tr>
              <tr>
                <td style="padding-top:9px;text-align:left" class=n>
								<font size="2" color="#FFFFFF">���ϻ�� - ���� 11:00 ~ ���� 7 :30<br><br>�� �� �ð��� ���ڼ��� ��Ź�帳�ϴ�.<br><br><br></font></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="10"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="45"><img src="skin/basic/image/N_custormer_title_01.gif" width="168" height="34"></td>
        </tr>
        <tr>
          <td background="skin/basic/image/M_line_01.gif" height="1"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="7"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
		      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="15"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="45"><img src="skin/basic/image/N_custormer_title_02.gif" width="168" height="34"></td>
        </tr>
        <tr> 
          <td background="skin/basic/image/M_line_01.gif" height="1"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td height="7"></td>
        </tr>
      </table>
      <table width="97%" border="0" cellspacing="0" cellpadding="0">
		
                    <tr> 
                      <td height="23" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><img src="skin/basic/image/N_icon_03.gif"></td>
                            <td class="dod8" style='padding-left:7px'><a href='m_view.php?ps_db=qna&ps_boid=4203' >�����ȣ</a></td>
                            <td align="right" width="55"><font color="#999999" class=thm7>2016/08/07</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>


                    <tr> 
                      <td height="23" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><img src="skin/basic/image/N_icon_03.gif"></td>
                            <td class="dod8" style='padding-left:7px'><a href='m_view.php?ps_db=qna&ps_boid=4202' >�Ա�Ȯ�ο�û</a></td>
                            <td align="right" width="55"><font color="#999999" class=thm7>2016/08/07</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>


                    <tr> 
                      <td height="23" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><img src="skin/basic/image/N_icon_03.gif"></td>
                            <td class="dod8" style='padding-left:7px'><a href='m_view.php?ps_db=qna&ps_boid=4201' >���� ���ǵ帳�ϴ�</a></td>
                            <td align="right" width="55"><font color="#999999" class=thm7>2016/08/06</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>


                    <tr> 
                      <td height="23" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><img src="skin/basic/image/N_icon_03.gif"></td>
                            <td class="dod8" style='padding-left:7px'><a href='m_view.php?ps_db=qna&ps_boid=4200' >��� ���� �� �帳�ϴ�.</a></td>
                            <td align="right" width="55"><font color="#999999" class=thm7>2016/08/06</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>


                    <tr> 
                      <td height="23" >
                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td width="15"><img src="skin/basic/image/N_icon_03.gif"></td>
                            <td class="dod8" style='padding-left:7px'><a href='m_view.php?ps_db=qna&ps_boid=4199' >���� �˱�� �� ��ǰ��</a></td>
                            <td align="right" width="55"><font color="#999999" class=thm7>2016/08/06</font></td>
                          </tr>
                        </table>
                      </td>
                    </tr>

      </table>
    </td>
    <td width="414" align="center"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td><img src="skin/basic/image/N_custormer_box_01.gif" width="414" height="102"></td>
        </tr>
        <tr>
          <td background="skin/basic/image/N_custormer_box_02.gif" align="center"> 
            <table width="350" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="10"></td>
              </tr>
            </table>

			<form method="post" action="m_mailer_ok.php" name="morning_mailer" onsubmit="javascript:return morning_callmailer_check()" style='border:0'>
			<input type="hidden" name="ps_mode" value="customer_mail">
			<input type="hidden" name="goods_model" value="">
			<input type="hidden" name="goods_img" value="">
            <input type="hidden" name="mailer_receive_name"  value="Ÿ�����ڸ���">
            <input type="hidden" name="mailer_receive_email" value="dr1phone@naver.com">
			<input type="hidden" name="url" value="/mall/m_customer.php">
			<input type="hidden" name="mailer_html" value="">

						<div style="padding-bottom:5px;font-weight:bolder;text-align:left;width:90%">�� ����������޹�ħ</div>
			<div style="border:1px solid #808080;width:90%">
				<div style="border:5px solid #D5D5D5;padding:10px;">
					<div style="width:100%;height:60px;overflow-y:scroll;text-align:left">
						<!--------------------- ����������޹�ħ1 --------------------->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><b><font color="#6633FF">:: �������� ��3�� ���� ����</font></b></td>
  </tr>
  <tr> 
    <td> 
    <td height=7></td>
    </td>
  </tr>
  <tr> 
    <td>
���⼭ ��3�ڴ� �����Բ� ��ǰ�� ����ϴ� ��۾�ü�� �ǹ��ϰ�, �̿ܿ��� ��� ��3�ڿ� ���� �������� ������ ���� �ʰ� �ֽ��ϴ�.<br>
��ǰ�� ��� ��ǰ ����� ���� �ʼ����� �ּ����� �������� ��۾�ü�� �����ϰ� �ֽ��ϴ�.<br>
�����Բ����� �̿� ���� �źθ� �Ͻ� �� ������, �̷� ��� �ش� ���Ű� �̷�� �� �� �����ϴ�. <br>
���������� �����޴��� : ��ǰ��۾�ü<br>
�������� : ������ ��ǰ�� ���<br>
�������� : ����,�޴�����ȣ,�ּ�<br>
���������� ���� �޴� ���� �������� ���� �� �̿�Ⱓ : 6����
	</td>
  </tr>
  <tr> 
    <td> 
      <div style='border-bottom:1px solid #dddddd;height:15px';border:1px solid red></div><div style='height:15px'></div>    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><b><font color="#6633FF">:: ���������� ����,�̿����</font></b></td>
  </tr>
  <tr> 
    <td> 
    <td height=7></td>
    </td>
  </tr>
  <tr> 
    <td>�� ���� �̿뿡 ���� ���νĺ�, �Ǹ�Ȯ��, �����ǻ�Ȯ��, �������� �����̿�<br>
      �� �������� ����, �Ҹ�ó�� �ǻ���� ��� Ȯ��, ��ǰ��� �� ��Ȯ�� ����� ���� Ȯ��<br>
      �� �ű� ���񽺵� �ֽ����� �ȳ� �� ���θ��㼭�� ������ ���� �ڷ�<br>
      �� �������� �̿뿡 ���� ��ݰ���<br>
      �� �ҷ�ȸ�� �����̿� ���� �� ���ΰ� ������<br>
      �� ��Ÿ ��Ȱ�� ������ ���� ������</td>
  </tr>
  <tr> 
    <td> 
      <div style='border-bottom:1px solid #dddddd;height:15px';border:1px solid red></div><div style='height:15px'></div>    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><b><font color="#6633FF">:: �����ϴ� ���������� �׸�</font></b></td>
  </tr>
  <tr> 
    <td> 
    <td height=7></td>
    </td>
  </tr>
  <tr> 
    <td>�� ����, ���̵�, ��й�ȣ, �̸����ּ�, ��ȭ��ȣ, IP���� �׿� �����׸�</td>
  </tr>
  <tr> 
    <td> 
      <div style='border-bottom:1px solid #dddddd;height:15px';border:1px solid red></div><div style='height:15px'></div>    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td><b><font color="#6633FF">:: ���������� ���� �� �̿�Ⱓ</font></b></td>
  </tr>
  <tr> 
    <td> 
    <td height=7></td>
    </td>
  </tr>
  <tr> 
    <td>�� ��Ģ������ ���������� ���� �Ǵ� �����޴� ���� �޼��� ��ü ���� �ı��մϴ�.<br>
      �� ��, �ҷ�ȸ���� �����̿� ��� ������ ���� �̿��� ���� �� ���̵� 3������ ������ �� ������<br>
      �� ���ڻ�ŷ������� �Һ��ں�ȣ�� ���� ���� �� Ÿ������ ���� ������ �ʿ䰡 �ִ� ��쿡�� �����Ⱓ �����մϴ�.</td>
  </tr>
</table>
<!---------------------// ����������޹�ħ1 --------------------->




<!--------------------- ����������޹�ħ2 --------------------->
<!---------------------// ����������޹�ħ2 --------------------->





<!--------------------- ����������޹�ħ3 --------------------->
<!--------------------- //����������޹�ħ3 --------------------->





<!--------------------- ȸ�����Ծ�� --------------------->
					</div>
				</div>
			</div>
			<div style="width:90%;text-align:left;margin:5px 0 20px 0">
				<input type="checkbox" name="accept2" value="1" style="border:0"> ���� �������� ��޹�ħ�� ��� �о����� �����մϴ�
			</div>
			
            <table width="350" border="0" cellspacing="0" cellpadding="3">
              <tr> 
                <td class=dod8><b>�̸�</b></td>
                <td> 
                  <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td>
                        <input type="text" name="mailer_send_name" value="" maxlength="20" class="input_">
                      </td>
                      <td style="padding-left:5px">
                        <select name="q_mode">
                          <option value="" selected>----- ��㼱�� -----</option>
						  <option value="ȸ������">ȸ������</option>
						  <option value="�ֹ�����">�ֹ�����</option>
						  <option value="��������">��������</option>
						  <option value="��۰���">��۰���</option>
						  <option value="���/��ǰ����">���/��ǰ����</option>
						  <option value="�����ݰ���">�����ݰ���</option>
						  <option value="��Ÿ">��Ÿ</option>
                        </select>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr> 
                <td class=dod8><b>�̸���</b></b></td>
                <td> 
                  <input type="text" name="mailer_send_email" value="" maxlength="20" class="input_" style='width:100%'>
                </td>
              </tr>
              <tr> 
                <td class=dod8><b>����</b></td>
                <td> 
                  <input type="text" name="mailer_subject" maxlength="20" class="input_" style='width:100%'>
                </td>
              </tr>
              <tr> 
                <td class=dod8><b>����</b></td>
                <td> 
                  <textarea name="mailer_body" class="input_" style='width:100%;height:200px'></textarea>
                </td>
              </tr>
            </table>
            <table width="350" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td height="10"></td>
              </tr>
              <tr>
                <td height="10" align="center"><input type=image src="skin/basic/image/N_custormer_bt_05.gif" width="45" height="21" style="border:0"> 
                  <a href="m_customer.php"><img src="skin/basic/image/N_custormer_bt_06.gif" width="45" height="21"></a></td>
              </tr>
            </table>
			</form>
          </td>
        </tr>
        <tr>
          <td><img src="skin/basic/image/N_custormer_box_03.gif" width="414" height="17"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td height="5"></td>
        </tr>
      </table>
      <table border="0" cellspacing="0" cellpadding="2">
        <tr>
          <td><a href="m_board.php?ps_db=notice" onfocus='this.blur()'><img src="skin/basic/image/N_custormer_bt_01.gif" width="99"></a></td>
          <td><a href="javascript:open_window('loss', 'm_member_loss.php', 40, 40, 420, 300, 0, 0, 0, 0, 0);" onfocus='this.blur()'><img src="skin/basic/image/N_custormer_bt_02.gif" width="99"></a></td>
          <td><a href="m_board.php?ps_db=qna" onfocus='this.blur()'><img src="skin/basic/image/N_custormer_bt_03.gif" width="99"></a></td>
          <td><a href="m_board.php?ps_db=faq" onfocus='this.blur()'><img src="skin/basic/image/N_custormer_bt_04.gif" width="99"></a></td>
        </tr>
      </table>
    </td>
  </tr>
</table>


<!----- faq ------>
<table width="98%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height=30></td>
  </tr>
</table>
<table width="99%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td style="padding-bottom:5px"><img src="skin/basic/image/N_custormer_faq.gif"></td>
  </tr>
</table>
<table width="98%" border="0" cellspacing="1" cellpadding="7" bgcolor="#D1D1D1">
  <tr>
    <td bgcolor="#EEEEEE">
	  <table width="100%" border="0" cellspacing="0" cellpadding="7" align="center">
	    <tr>
	      <td bgcolor="#ffffff">
			<table border="0" cellspacing="0" cellpadding="2">
			<form action="m_board.php?" method="get" name="search_form">
			<input type="hidden" name="ps_db" value="">
			<input type="hidden" name="ps_sele" value="subject">
			<input type="hidden" name="ps_db" value="faq">
			  <tr>
				<td class=dod8 style="padding-right:15px">�ñ��Ͻ� ������ �����ø� FAQ�� �̿��غ�����.</td>
				<td><input type="text" name="ps_ques" size="50" maxlength="20" class="input_" style='width:350px'></td>
				<td style='padding-left:4px'><input type="image" src="image/bt_search.gif" style="border:0" onclick="this.form.submit()"></td>
			  </tr>
			</form>
			</table>
		  </td>
	    </tr>
	  </table>
	</td>
  </tr>
</table><script type="text/javascript">
//���̹�üũ�ƿ�
wcs_do();
</script>

	
	</td>
	</tr>
	</table>
	<div style="height:30px"></div>
    <table border="0" cellspacing="0" cellpadding="0" width="980" style="margin:0 auto">
    <tr valign="top">
    <td><img src='./board_data/c4.jpg' width='236' height='180' border='0'></td>
    <td><img src='http://cfile5.uf.tistory.com/image/2727753E5523D54316A49B' width='232' height='180' border='0'></td>
    <td><img src="skin/basic/images/main_bottom_quick.gif" border="0" usemap="#bottom_quick" /></td>
    <td><img src='./board_data/%B9%DD%BC%DB2.jpg' width='297' height='180' border='0'></td>
    </tr>
    </table>
	
	<table cellpadding="0" cellspacing="0" align="center" style="margin:0 auto">
	<tr>
	<td><img src="skin/basic/images/main_footer_nav.gif" alt="" usemap="#footer"></td>
	</tr>
	<tr>
	<td>
		<table cellpadding="0" cellspacing="0" width="100%">
		<tr>
		<td width="100%" style="">
			<table cellpadding="10" cellspacing="0" width="100%">
			<tr>
			<td valign="top"> 

			<table width="100%" border="0" cellspacing="0" cellpadding="1">
              <tr>
                <td style="padding-bottom:10">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td class=n>
						<b>�����ð�</b> ���ϻ�� - ���� 11:00 ~ ���� 7 :30

�� �� �ð��� ���ڼ��� ��Ź�帳�ϴ�.


<span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>��ǥ��ȭ <font color="#FF6600">070-7660-6773</font></b> <span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>�߱�����ȭ +86 18565802423<span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>      dr1phone@naver.com</font>
					  </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding-top:7" class=n>
				   ��ȣ : ����&#23572;Ρ����������<span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>�ּ� : ��&#22269;&#24191;&#19996;���&#22323;����&#21306;&#22253;&#23725;ʶԳ&#21150;&#21326;&#21457;����46&#21495;����&#36798;������18&#23618;1805ۮ ��)518033 <span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>����ڵ�Ϲ�ȣ : 440306104585325 <span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>����Ǹž��Ű� : 440306104585325                   <br>
				  
                  ��ǥ : JINCHUNLONG<span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>
				  �������� ����å���� : JINCHUNLONG<span style="padding:0 5px 0 5px;color:#CCCCCC">|</span>
				  �������� ��ȣ�Ⱓ : ȸ��Ż���<br>
				  copyright�� tao2korea All rights reserved. Designed by wepas.com
				</td>
              </tr>
            </table>
			
			
			
			  
			</td>
			</tr>
			</table>	
		</td>
		</tr>
		</table>	
	
	</td>
	</tr>
	</table>
	
</td>
</tr>
</table>
<map name="footer">
  <area alt="" coords="908,2,979,35" href="#" onfocus="blur()">
<area alt="" coords="293,2,351,35" href="m_customer.php" onfocus="blur()">
<area alt="" coords="190,2,289,36" href="m_page.php?ps_pname=page_private2" onfocus="blur()">
<area alt="" coords="129,5,188,34" href="m_page.php?ps_pname=page_member2" onfocus="blur()">
<area alt="" coords="70,5,125,35" href="m_page.php?ps_pname=page_use" onfocus="blur()">
<area alt="" coords="10,4,61,35" href="m_page.php?ps_pname=page_company" onfocus="blur()">
</map>

<map name="bottom_quick" id="bottom_quick">
  <area shape="rect" coords="110,107,190,131" href="m_board.php?ps_db=qna" onfocus="blur()" />
  <area shape="rect" coords="23,107,109,130" href="m_board.php?ps_db=1n1qna" onfocus="blur()" />
  <area shape="rect" coords="23,131,108,155" href="m_mall_review.php" onfocus="blur()" />
  <area shape="rect" coords="109,130,190,155" href="m_mypage.php" onfocus="blur()" />
</map>
	


</body>
</html>


<!--
 SHOPINGMALL PROGRAM 

 Total Program Operation Time : 0.1893
-->


<!--
######################[ ���θ� ���۱� ���� ]################################
�� ���θ��� http://www.wepas.com���� ���۵� ���θ��μ� ���۱� ��ȣ�� 
�ް� �ֽ��ϴ�.
�ַ�� ������ ���Ͻø� http://www.wepas.com���� ���� �Ͻñ� �ٶ��ϴ�.
�κ����� �ҽ�(�ڵ�,���α׷��ҽ�)�� �������Ͽ� ������ ��Ų�� ����
�ϰų� ���Ǹ� �ϴ� ������ �����մϴ�.
----------------------------------------------------------------------------
1ȸ���Խ� 1�� �����ο����� ����� �����ϸ�.. �����Ͽ� �㰡 ���� 
���Ǵ� ���� �����Դϴ�.
----------------------------------------------------------------------------
############################################################################-->
